//#pragma GCC optimize("Ofast")
//#pragma GCC target("avx")
//#undef LOCAL

#include "base.h"
#include "util/fast_io.h"

Scanner sc = Scanner(stdin);
Printer pr = Printer(stdout);

int main() {
    return 0;
}

